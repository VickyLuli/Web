<?php
if ($_GET["borrar"]) {
	
}
?>
